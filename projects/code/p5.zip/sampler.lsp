;; sampler.lsp -- this is a patch. Load this after starting Nyquist. This patch
;;   will replace SAMPLER with a correct implementation.

;; SAMPLER -- simple attack + sustain sampler
;;
(defun sampler (pitch modulation 
                &optional (sample *SINE-SAMPLE*) (npoints 2))
  (ny:typecheck (not (numberp pitch))
    (ny:error "SAMPLER" 1 '((STEP) "pitch") pitch))
  (ny:typecheck (not (soundp modulation))
    (ny:error "SAMPLER" 2 '((SOUND) "modulation") modulation))
  (ny:assert-sample "SAMPLER" 3 "table" sample)
  (ny:typecheck (not (integerp npoints))
    (ny:error "BUZZ" 3 '((INTEGER) "npoints") npoints))
  (let ((samp (car sample))
        (samp-pitch (cadr sample))
        (samp-loop-start (caddr sample))
        (hz (calculate-hz pitch "sampler nominal")))
    ; make a waveform table look like a sample with no attack:
    (cond ((not (numberp samp-loop-start))
           (setf samp-loop-start 0.0)))
    (ny:scale-db (get-loud)
       (snd-sampler 
        samp		; samples for table
        samp-pitch	; step represented by table
        samp-loop-start ; time to start loop
        *SOUND-SRATE*	; output sample rate
        hz		;  output hz
        (local-to-global 0)	; starting time
        modulation	; modulation
        npoints))))    	; number of interpolation points

print "SAMPLER function has been patched"

